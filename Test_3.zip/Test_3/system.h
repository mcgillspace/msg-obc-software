#ifndef __SYSTEM_H
#define __SYSTEM_H

#define SYSTEM_APP_ID OBC_APP_ID

#endif
